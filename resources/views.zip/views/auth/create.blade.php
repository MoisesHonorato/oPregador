@extends('template')

@section('title', 'Criar Pregação :: O Pregador')

@section('conteudo')

   

@endsection()
